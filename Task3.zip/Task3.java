public class Task3 
{
    public static String checkStrength(String password) 
	{
        int score = 0;

        // Length check
        if (password.length() >= 8) 
		{
            score++;
        }
        if (password.length() >= 12) 
		{
            score++;
        }

        // Contains uppercase
        if (password.matches(".*[A-Z].*")) 
		{
            score++;
        }

        // Contains lowercase
        if (password.matches(".*[a-z].*")) 
		{
            score++;
        }

        // Contains number
        if (password.matches(".*[0-9].*")) 
		{
            score++;
        }

        // Contains special character
        if (password.matches(".*[!@#$%^&*(),.?\":{}|<>].*")) 
		{
            score++;
        }

        // Decide strength based on score
        if (score <= 2) {
            return "Weak";
        } else if (score == 3) {
            return "Good";
        } else if (score == 4) {
            return "Very Good";
        } else if (score == 5) {
            return "Strong";
        } else {
            return "Excellent";
        }
    }

    public static void main(String[] args) 
	{
        String[] passwords = {
            "yash", "yash12", "Yash12", "Yash12@", "MyPassw0rd@2025"
        };

        for (String pwd : passwords) 
		{
            System.out.println(pwd + " -> " + checkStrength(pwd));
        }
    }
}
